/**
 * Animation
 * @constructor
 */

function Animation(scene, span) {
    this.scene = scene;
    this.span = span;
}
